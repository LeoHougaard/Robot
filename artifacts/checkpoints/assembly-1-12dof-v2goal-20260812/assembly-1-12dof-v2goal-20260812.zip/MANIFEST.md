# Assembly 1 12-DOF checkpoint (2026-08-12 18:37:21)

This is the preserved Isaac Lab V2 Goal policy selected before correcting the
robot's rear-leg knee geometry. It is retained so the known passing behavior
can be tested or reproduced, but it must not be treated as the starting policy
for a kinematically different articulation.

## Contents

- `policy.pth`: promoted RL-Games checkpoint at epoch 3450.
- `control-profile.json`: exact evaluated profile, SHA-256 identity prefix
  `f63594934cca`.
- `agent.yaml` and `env.yaml`: saved RL-Games/Isaac run configuration.
- `goal-evaluation.json`: deterministic recorded Goal evaluation.

## Verified result

- Goal evaluation: pass, zero failures and zero resets.
- Commands: stand, stop, turn left/right, walk left/right.
- Right-walk mean vertical speed: 0.0911 m/s.
- Right-walk mean foot slip: 0.3286 m/s.
- Maximum normalized action step: 0.30.

## Policy checksum

`policy.pth` SHA-256:
`235A330A9BCA715DB303C472BBAB84E29989B0F96102EFC9E36E5F6BDE85F95C`

The checkpoint expects the 180-value V2 observation contract and 12 actions.
Use only with the included joint mapping, ordering, direction signs, action
scale, and control rate unless the policy is retrained for a changed contract.
